# sql_3
Conteudo de SQL do 3º Trimestre - CEEP Cianorte

50 pontos -> projeto em sala de aula - C.E.R.A
